<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="../icons/SG2.png">
    <title>Store Games</title>
</head>
<body>
    <header>
        <nav>
            <div class="nav-content">
                <div class="logo_img">
                    <a href="index.php">
                        <img class="img" src="../img/logo3.png" alt="Logo">
                    </a>
                </div>
                <div class="logo">
                    <a href="index.php">Store Gaming</a>
                </div>
                <ul class="nav-links">
                    <li><a href="screens/#">Sobre</a></li>
                    <li><a href="screens/#">Notícias</a></li>
                    <li><a href="screens/#">Contatos</a></li>
                    <form action="../login/login.php">
                    <li><button class="btn_login">Login</button></li>
                    </form>
                </ul>
            </div>
        </nav>
    </header>

        

    </body>
</html>